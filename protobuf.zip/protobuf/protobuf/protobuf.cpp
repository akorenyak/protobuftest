#include "protobuf.h"


Protobuf::Protobuf()
{
}
