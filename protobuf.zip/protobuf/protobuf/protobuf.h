#ifndef PROTOBUF_H
#define PROTOBUF_H


class Protobuf
{

public:
    Protobuf();
};

#endif // PROTOBUF_H
